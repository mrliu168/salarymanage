#!/bin/bash
docker pull registry.cn-hangzhou.aliyuncs.com/agoraio-public/agora_cap_sync:release-v1_1_0-20230614
docker rm -f agora_cap_sync
docker run -i -t -d --network host --pid host --restart=unless-stopped --privileged --name agora_cap_sync \
    -v /ly/logs:/var/log/agora -v /tmp:/tmp \
    registry.cn-hangzhou.aliyuncs.com/agoraio-public/agora_cap_sync:release-v1_1_0-20230614
