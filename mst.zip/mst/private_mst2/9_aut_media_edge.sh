#!/bin/bash
docker pull registry.cn-hangzhou.aliyuncs.com/agoraio-public/agora_aut_media_edge:release-v2_1_0-20230516
docker run -i -t -d --network host --pid host --restart=unless-stopped --name agora_aut_media_edge \
    -v `pwd`/agora:/etc/agora -v /ly/logs:/var/log/agora -v  /tmp:/tmp \
    registry.cn-hangzhou.aliyuncs.com/agoraio-public/agora_aut_media_edge:release-v2_1_0-20230516 \
    --ip-for-client 10.157.12.60 --ip-for-comm 10.157.12.60 \
    --ap 10.157.12.60 --sync 10.157.12.60 --balancer 10.157.12.60


    


