#!/usr/bin/python3

import copy
import json
import os
import shutil
import sys
import traceback
import uuid
import http.client
import json
import time
import base64

from urllib import response

class PacketManifestReader:
    def __init__(self, path):
        self._path = path

    def PrintImageTable(self):
        with open(self._path, "r") as fo:
            obj = json.load(fo)
            if "images" in obj:
                imgs = obj["images"]
                for img in imgs:
                    if 'id' in img and 'name' in img:
                        print("{0}\t{1}".format(img['id'], img['name']))
    
    def GetImages(self):
        imgs = {}
        with open(self._path, "r") as fo:
            obj = json.load(fo)
            if "images" in obj:
                for img in obj['images']:
                    if 'id' not in img or 'name' not in img:
                        return None

                    imgs[img['id']] = img['name']

        return imgs

class Deployment:
    def __init__(self, root_path, roles, force_install = False):
        self._root_path = root_path
        self._config_path = os.path.join(root_path, 'deploy.json')
        self._instance_id = ''
        self._hosts = {}
        self._certs = {}
        self._deployments = []
        self._controller_hosts = []
        self._datahub_hosts = []
        self._edge_hosts = []
        self._package_manifest_path = ''
        self._images = {}
        self._monitor_influxdb_host = ''
        self._monitor_opntsdb_host = ''
        self._monitor_hosts = []
        self._force_install = force_install
        self._global_params = {}

        # Roles specified by user, which may have suffix '+'/'-'
        self._specified_roles = roles
        # Actual roles to be installed
        self._roles = set()

    def _ProcessRoles(self):
        roles = set(["edge", "controller", "monitor", "init", "datahub"])
        if self._specified_roles == None or len(self._specified_roles) == 0:
            self._roles = roles
            return True

        included = set()
        excluded = set()
        for x in self._specified_roles:
            if x[-1] == '+':
                if x[:-1] not in roles:
                    print("Role {0} is not valid.".format(x), file=sys.stderr)
                    return False

                included.add(x[:-1])
            elif x[-1] == '-':
                if x[:-1] not in roles:
                    print("Role {0} is not valid.".format(x), file=sys.stderr)
                    return False

                excluded.add(x[:-1])
            else:
                if x not in roles:
                    print("Role {0} is not valid.".format(x), file=sys.stderr)
                    return False

                included.add(x)

        if len(included) > 0 and len(excluded) > 0:
            print("It's ambiguous to specify included roles and excluded roles both.", file=sys.stderr)
            return False
        elif len(included) > 0:
            self._roles = included
            return True
        elif len(excluded) > 0:
            self._roles = roles - excluded
            return True
        
        return False

    def _ConstructRoleParams(self, d):
        params = copy.deepcopy(self._global_params)
        if isinstance(d, dict):
            for k,v in d.items():
                params[k] = v

        return params

    @staticmethod
    def OverrideParametersWithHost(params, host):
        if 'params' not in host or not isinstance(host['params'], dict) or not isinstance(params, dict):
            return False

        for k,v in host['params'].items():
            params[k] = v
        return True

    def ExecuteAnsiblePlay(host, pb, vs):
        passwords = None
        ssh = host['ssh']
        ip = ssh['ip']
        cmdline = "-u {0}".format(ssh['user'])
        password = ssh['password']
        if password != None and len(password) > 0:
            ssh_prompt_pattern="SSH\\s+password:"
            become_prompt_pattern="^BECOME password.*:\\s*?$"
            passwords = {ssh_prompt_pattern: password, become_prompt_pattern: password}
            cmdline += " --ask-pass"
            cmdline += " --ask-become-pass"
            cmdline += " --become"

        if len(ssh['key']) > 0:
            key_path = ssh['key']
            if not os.path.isabs(key_path):
                key_path = os.path.join(self._root_path, 'user_assets', key_path)

            if not os.path.exists(key_path):
                print("SSH key {0} does not exist.".format(key_path), file=sys.stderr)
                return False
                
            tgt_path = os.path.join(self._root_path, 'resource/ansb/env/ssh_key')
            try:
                shutil.copyfile(key_path, tgt_path)
            except:
                print("Failed to copy ssh key file.", file=sys.stderr)
                return False
        print(pb)
        try:
            res = ansb_run(private_data_dir='./resource/ansb', playbook=pb, cmdline=cmdline,
                    extravars=vs, limit=ip, passwords=passwords, suppress_env_files=True)
        except Exception as e:
            print("Failed to execute ansible playbook {0}".format(pb), file=sys.stderr)
            return False
        if res == None or res.stats == None or ip in res.stats['failures'] or ip in res.stats['dark']:
            return False

        print("DeployedAnsibleJob. playbook: {0}; user: {3}; ip: {4}; stats: {2}; vars: {1}.".format(pb, vs, res.stats, ssh['user'], ip))
        return True

    @staticmethod
    def NormalizeHost(h):
        if 'host_id' not in h or 'network' not in h:
            return None

        if 'default_ip' not in h['network']:
            return None

        n = h['network']
        default_ip = n['default_ip']
        if 'ip_for_client' not in n or len(n['ip_for_client']) == 0:
            n['ip_for_client'] = default_ip

        if 'ip_for_comm' not in n or len(n['ip_for_comm']) == 0:
            n['ip_for_comm'] = default_ip

        if 'ssh' not in h:
            h['ssh'] = {}

        s = h['ssh']
        if 'ip' not in s:
            s['ip'] = default_ip

        if 'user' not in s or not s['user']:
            s['user'] = os.environ.get('USER')

        if 'port' not in s or not s['port']:
            s['port'] = 22

        if 'key' not in s:
            s['key'] = ''

        if 'password' not in s:
            s['password'] = ''

        return h

    @staticmethod
    def NormalizeHostInDeployment(h):
        if isinstance(h, str):
            return { 'host': h, 'params': {}}

        if not isinstance(h, dict) or 'host' not in h or isinstance(h['host'], str):
            return None

        if 'params' not in h:
            h['params'] = {}

        return h

    def ProcessCertificateInParams(self, params, keys):
        for k in keys:
            if k not in params:
                return False

            if params[k] not in self._certs:
                return False

            params[k] = self._certs[params[k]]
        return True

    def ConstructInitializationParams(self, h):
        res = {'instance_id': self._instance_id, 'host_ip': h['network']['ip_for_client'], 'monitor_influxdb_host' : self._monitor_influxdb_host, 'monitor_opentsdb_host' : self._monitor_opntsdb_host }
        cadvisor_key = 'cadvisor'  
        netdata_key = 'netdata'
        if cadvisor_key not in self._images and netdata_key not in self._images:
            return None

        res['cadvisor_image_file'] = cadvisor_key
        res['cadvisor_image_name'] = self._images[cadvisor_key]
        res['netdata_image_file'] = netdata_key
        res['netdata_image_name'] = self._images[netdata_key]
        res['force_install'] = self._force_install
        return res

    def Initialize(self):
        if not self._ProcessRoles():
            return False
        
        dir_path = os.path.join(self._root_path, "resource/tools")
        self._package_manifest_path = os.path.join(dir_path, 'package.json')
        if not os.path.isfile(self._package_manifest_path):
            print("package.json doesn't exist.", file=sys.stderr)
            return False

        mr = PacketManifestReader(self._package_manifest_path)
        imgs = mr.GetImages()
        if imgs == None:
            return False

        self._images = imgs  # img_id -> img_name

        if len(self._instance_id) > 0:
            return True

        self._instance_id = str(uuid.uuid4())
        print('deploymnent instance: {0}\n'.format(
            self._instance_id), file=sys.stderr)

        if not os.path.isfile(self._config_path):
            print('config file "{0}" doesn\'t exists\n'.format(
                self._config_path), file=sys.stderr)
            return False

        # Read deploy.json
        co = None
        try:
            f = open(self._config_path, 'r')
            co = json.load(f)
            f.close()
        except:
            print('failed to read config from config file, {0}\n'.format(
                sys.exc_info()[1]), file=sys.stderr)
            return False

        if 'params' in co:
            self._global_params = co['params']

        # Normalize hosts
        if 'hosts' not in co:
            print("No host is found, and they're required.", file=sys.stderr)
            return False

        for h in co['hosts']:
            nh = Deployment.NormalizeHost(h)
            if nh == None:
                print("Invalid host.", file=sys.stderr)
                return False

            self._hosts[nh['host_id']] = nh  # host_id -> host info

        # To use ansible runner, all ips have to be in hosts file
        hosts_path = os.path.join(self._root_path, 'resource/ansb/inventory/hosts')
        with open(hosts_path, 'w') as hosts_fo:
            for h in self._hosts.values():
                hosts_fo.write('{0}\n'.format(h['ssh']['ip']))
        
        user_assets_folder = os.path.join(self._root_path, 'user_assets')
        user_assets_files = []
        if not os.path.isdir(user_assets_folder):
            print("Folder user_assets doesn't exist.", file=sys.stderr)
            return False
        else:
            for f in os.listdir(user_assets_folder):
                if os.path.isfile(os.path.join(user_assets_folder, f)):
                    user_assets_files.append(f)

        ansb_files_folder = os.path.join(self._root_path, 'resource/ansb/project/files')
        tgt_user_assets_folder = os.path.join(ansb_files_folder, 'user_assets')
        if not os.path.exists(tgt_user_assets_folder):
            shutil.copytree(user_assets_folder, tgt_user_assets_folder)
        else:
            if not os.path.isdir(tgt_user_assets_folder):
                print("./resource/ansb/project/files/user_assets is expected as a directory, but it isn't.", file=sys.stderr)
                return False
            else:
                for f in os.listdir(user_assets_folder):
                    s = os.path.join(user_assets_folder, f)
                    d = os.path.join(tgt_user_assets_folder, f)
                    if os.path.isdir(s):
                        shutil.copytree(s, d)
                    else:
                        shutil.copy2(s, d)

        # Prepare and check artifacts
        if 'artifacts' in co:
            if 'certificates' in co['artifacts']:
                self._certs = co['artifacts']['certificates']
                for k,v in self._certs.items():
                    if v not in user_assets_files:
                        print("Certificate {0}:{1} defined in deploy.json doesn't exist in user_assets folder.".format(k, v), file=sys.stderr)
                        return False

        if 'deployments' not in co:
            print("No deployment is found, and they're required.", file=sys.stderr)
            return False

        # First pass, extract dependencies to enable deploy roles separately.
        for d in co['deployments']:
            if d['name'] == 'agora_media_controller':
                for h in d['hosts']:
                    host = self._hosts[h['host']]
                    if host:
                        self._controller_hosts.append(host)
            elif d['name'] == 'agora_datahub':
                host = self._hosts[d['hosts'][0]['host']]
                if host:
                    self._datahub_hosts.append(host)
            elif d['name'] == 'agora_monitor':
                host = self._hosts[d['hosts'][0]['host']]
                if host:
                    self._monitor_influxdb_host = host['network']['ip_for_comm'] + ':8086'
                    self._monitor_opntsdb_host = host['network']['ip_for_comm'] + ':4242'
                    self._monitor_hosts.append(host)

        for d in co['deployments']:
            self._deployments.append(d)

        return True

    def GetControllerIps(self):
        controller_ips = []
        for h in self._controller_hosts:
            controller_ips.append(h['network']['ip_for_comm'])

        return controller_ips

    def Execute(self):
        # Deploy proxy monitor
        if "monitor" in self._roles:
            for d in self._deployments:
                if d['type'] != 'docker':
                    continue

                if d['name'] == 'agora_monitor':
                    params = self._ConstructRoleParams(d.get('params', {}))
                    if 'hosts' not in d or not isinstance(d["hosts"], list) or len(d["hosts"]) == 0 or not isinstance(d["hosts"][0], dict) or not "host" in d["hosts"][0]:
                        print("Invalid hosts in deployment for monitor.".format(ip), file=sys.stderr)
                        return False

                    h = d['hosts'][0]['host']
                    if h not in self._hosts:
                        print("Host {0} is not declared.".format(h), file=sys.stderr)
                        return False

                    host = self._hosts[h]
                    print("Monitor influxdb host: {0}".format(self._monitor_influxdb_host))
                    ip = host['ssh']['ip']
                    vs = self.ConstructMonitorParams(params, host)
                    if vs == None:
                        print("Error occurred when constructing parameters for monitor.", file=sys.stderr)
                        return False

                    if not Deployment.ExecuteAnsiblePlay(host, 'monitor.yml', vs):
                        print("Error occurred when deploying monitor on {0}".format(ip), file=sys.stderr)
                        return False

        # Deploy controllers
        if "controller" in self._roles:
            for d in self._deployments:
                if d['type'] != 'docker':
                    continue

                if d['name'] == 'agora_media_controller':
                    common_params = self._ConstructRoleParams(d.get('params', self._global_params))
                    for h in d['hosts']:
                        Deployment.NormalizeHostInDeployment(h)
                        if h['host'] not in self._hosts:
                            print("Host {0} is not declared.".format(h['host']), file=sys.stderr)
                            return False

                        host = self._hosts[h['host']]
                        ip = host['ssh']['ip']
                        params = common_params.copy()
                        vs = self.ConstructControllerParams(params, h)
                        if vs == None:
                            print("Error occurred when constructing parameters for controller.", file=sys.stderr)
                            return False
                        if not Deployment.ExecuteAnsiblePlay(host, 'controller.yml', vs):
                            print("Error occurred when deploying controller on {0}".format(ip), file=sys.stderr)
                            return False

        # Deploy edges
        if "edge" in self._roles:
            for d in self._deployments:
                if d['type'] == 'docker':
                    if d['name'] == 'agora_media_edge':
                        common_params = self._ConstructRoleParams(d.get('params', self._global_params))
                        for h in d['hosts']:
                            if h['host'] not in self._hosts:
                                print("Host {0} is not declared.".format(h['host']), file=sys.stderr)
                                return False

                            Deployment.NormalizeHostInDeployment(h)
                            host = self._hosts[h['host']]
                            ip = host['ssh']['ip']
                            params = common_params.copy()
                            vs = self.ConstructEdgeParams(params, h)
                            if vs == None:
                                print("Error occurred when constructing parameters for edge.", file=sys.stderr)
                                return False

                            if not Deployment.ExecuteAnsiblePlay(host, 'edge.yml', vs):
                                print("Error occurred when deploying edge on {0}".format(ip), file=sys.stderr)
                                return False

        # Deploy cadvisor and other init steps
        if "init" in self._roles:
            for h in self._hosts.values():
                init_vars = self.ConstructInitializationParams(h)
                if init_vars == None:
                    return False

                if not Deployment.ExecuteAnsiblePlay(h, 'init.yml', init_vars):
                    print("Error occurred when deploying init on {0}".format(h['ssh']['ip']), file=sys.stderr)
                    return False
        
        # Deploy datahub
        if "datahub" in self._roles:
            for d in self._deployments:
                if d['type'] == 'docker':
                    if d['name'] == 'agora_datahub':
                        params = self._ConstructRoleParams(d.get('params', self._global_params))
                        if 'hosts' not in d or not isinstance(d["hosts"], list) or len(d["hosts"]) == 0 or not isinstance(d["hosts"][0], dict) or not "host" in d["hosts"][0]:
                            print("Invalid hosts in deployment for monitor.".format(ip), file=sys.stderr)
                            return False

                        h = d['hosts'][0]['host']
                        if h not in self._hosts:
                            print("Host {0} is not declared.".format(h), file=sys.stderr)
                            return False

                        Deployment.NormalizeHostInDeployment(h)
                        host = self._hosts[h]
                        ip = host['ssh']['ip']
                        vs = self.ConstructDatahubParams(params, h)
                        print(vs)
                        if vs == None:
                            print("Error occurred when constructing parameters for datahub.", file=sys.stderr)
                            return False

                        if not Deployment.ExecuteAnsiblePlay(host, 'datahub.yml', vs):
                            print("Error occurred when deploying datahub on {0}".format(ip), file=sys.stderr)
                            return False

        return True

    def PrintHosts(self):
        co = None
        try:
            f = open(self._config_path, 'r')
            co = json.load(f)
            f.close()
        except:
            print('failed to read config from config file, {0}\n'.format(
                sys.exc_info()[1]), file=sys.stderr)
            return False

        # Normalize hosts
        if 'hosts' not in co:
            print("No host is found, and they're required.", file=sys.stderr)
            return False

        for h in co['hosts']:
            nh = Deployment.NormalizeHost(h)
            if nh == None:
                print("Invalid host.", file=sys.stderr)
                return False

            print(nh['ssh']['ip'])


    def ConstructControllerParams(self, params, host):
        if isinstance(host, str):
            host = { "host": host, "params": {}}
        elif isinstance(host, dict):
            if 'host' not in host:
                return None

            if 'params' not in host:
                host['params'] = {}
        else:
            return None

        if params == None:
            params = {}

        if not Deployment.OverrideParametersWithHost(params, host):
            return None
        
        cert_ks = [ 'tls_cert', 'tls_cert_key', 'web_cert', 'web_cert_key' ]
        if not self.ProcessCertificateInParams(params, cert_ks):
            return False

        res = params
        if 'agora_local_ap' not in self._images:
            return None

        res['local_ap_image_file'] = 'agora_local_ap'
        res['local_ap_image_name'] = self._images['agora_local_ap']

        if 'agora_local_sync' not in self._images:
            return None

        res['lpsync_image_file'] = 'agora_local_sync'
        res['lpsync_image_name'] = self._images['agora_local_sync']

        if 'agora_cap_sync' not in self._images:
            return None

        res['cap_sync_image_file'] = 'agora_cap_sync'
        res['cap_sync_image_name'] = self._images['agora_cap_sync']

        if 'vid_map' not in params:
            return None

        tmp_vid = []
        for e in params['vid_map']:
            if 'app_id' in e and 'vid' in e:
                tmp_vid.append(e['app_id'] + ':' + str(e['vid']))

        res['vendors'] = ','.join(tmp_vid)
        res['force_install'] = self._force_install
        return res

    def ConstructEdgeParams(self, params, host):
        if isinstance(host, str):
            host = { "host": host, "params": {}}
        elif isinstance(host, dict):
            if 'host' not in host:
                return None

            if 'params' not in host:
                host['params'] = {}
        else:
            return None

        if params == None:
            params = {}

        if not Deployment.OverrideParametersWithHost(params, host):
            return None

        cert_ks = ['web_cert', 'web_cert_key']
        if not self.ProcessCertificateInParams(params, cert_ks):
            return None

        res = params
        res['native_proxy_image_file'] = 'agora_native_proxy'
        res['native_proxy_image_name'] = self._images['agora_native_proxy']
        res['web_proxy_image_file'] = 'agora_web_proxy'
        res['web_proxy_image_name'] = self._images['agora_web_proxy']
        res['event_collector_image_file'] = 'agora_event_collector'
        res['event_collector_image_name'] = self._images['agora_event_collector']
        res['nginx_image_file'] = 'nginx'
        res['nginx_image_name'] = self._images['nginx']

        jd_ips = []
        for c in self._datahub_hosts:
            jd_ips.append(c['network']['ip_for_comm'])
        jips = ','.join(jd_ips)
        res['report'] = jips


        if 'host' not in host or host['host'] not in self._hosts:
            return None

        n = self._hosts[host['host']]['network']
        res['ip_for_client'] = n['ip_for_client']
        res['ip_for_comm'] = n['ip_for_comm']

        ctrl_ips = []
        for c in self._controller_hosts:
            ctrl_ips.append(c['network']['ip_for_comm'])

        ips = ','.join(ctrl_ips)
        res['controller_addrs'] = ips

        log_compass_ips = [h['network']['ip_for_comm'] for h in self._monitor_hosts]
        res['log_compass_addrs'] =  ','.join(log_compass_ips)
        res['force_install'] = self._force_install
        return res

    def ConstructDatahubParams(self, params, host):
        if isinstance(host, str):
            host = { "host": host, "params": {}}
        elif isinstance(host, dict):
            if 'host' not in host:
                return None

            if 'params' not in host:
                host['params'] = {}
        else:
            return None

        if params == None:
            params = {}

        if not Deployment.OverrideParametersWithHost(params, host):
            return None

        cert_ks = [ 'tls_cert', 'tls_cert_key', 'web_cert', 'web_cert_key' ]
        if not self.ProcessCertificateInParams(params, cert_ks):
            return None

        params['log_compass_ip'] = self._monitor_hosts[0]['network']['ip_for_comm']
        res = params.copy()
        
        if 'host' not in host or host['host'] not in self._hosts:
            return None

        vendor=[]
        for e in params['vid_map']:
            entry = ""
            if 'vid' in e:
                entry = str(e['vid'])
            else:
                print("Vid is missing", file=sys.stderr)
                return False

            if 'name' in e:
                entry += ",{0}".format(e['name'])
            else:
                entry += ",Unknown"

            entry += "\n"
            vendor.append(entry)
        res['vendors']="".join(vendor)
        res['force_install'] = self._force_install

        app_env_path = os.path.join(self._root_path, 'resource/ansb/project/files/application.env')
        if not os.path.isfile(app_env_path):
            return False

        images = {}
        with open(app_env_path) as app_env_fo:
            for l in app_env_fo:
                ps = l.split('=')
                if len(ps) < 2:
                    continue
                if not ps[0].endswith('_IMAGE'):
                    continue
                
                images[ps[0]] = ps[1].strip()

        res['images'] = images
        return res

    def FindImage(self, k):
        if k not in self._images:
            return None

        return self._images[k]

    def ConstructMonitorParams(self, params, host):
        res = {}
        influx_k = 'influxdb_img'
        res['influxdb_image_file'] = influx_k
        res['influxdb_image_name'] = self.FindImage(influx_k)
        if res['influxdb_image_name'] == None:
            return None

        grafana_k = 'grafana_img'
        res['grafana_image_file'] = grafana_k
        res['grafana_image_name'] = self.FindImage(grafana_k)
        if res['grafana_image_name'] == None:
            return None

        res['grafana_domain_ip'] = host['network']['ip_for_comm']

        server_log_db_k = 'server_log_database'
        res['server_log_database_image_file'] = server_log_db_k
        img = self.FindImage(server_log_db_k)
        if img == None:
            return None

        res['server_log_database_image_name'] = img

        server_log_compass_k = 'server_log_compass'

        res['server_log_compass_image_file'] = server_log_compass_k
        img = self.FindImage(server_log_compass_k)
        if img == None:
            return none

        res['server_log_compass_image_name'] = img
        res['force_install'] = self._force_install
        return res

class LicenseWorkflow:
    def __init__(self, controllers):
        self._controller_ips = controllers

    def CollectHardwareInfo(self, cluster_info_path, output_path):
        req = None
        try:
            f = open(cluster_info_path, 'rb')
            content = f.read()
            b64 = base64.b64encode(content)
            req = str(b64, encoding = 'utf-8')
        except Exception as ex:
            print("Failed to read input file: {0}".format(cluster_info_path));
            return 1
        
        json_obj = {
            "schemaVer":1,
            "clusterId": "",
            "ehs": [],
            "license": "",
            "reqTs":int(time.time())
        }

        req_body = json.dumps({"raw_apply_string" : req})
        header = {"Content-type": "application/json"}
        for ip in self._controller_ips:
            conn = http.client.HTTPConnection(ip + ':8010', timeout=10)
            try:
                conn.request("POST", "/api/v1/license_req", req_body, headers=header)
            except Exception as e:
                print("Failed to connect to {0}:{1}".format(ip, e))
                continue

            response = conn.getresponse()
            code = response.status
            reason = response.reason
            if code == 200:
                try:
                    resp_body = json.loads(response.read().decode('utf-8'))
                except Exception as e:
                    print("Failed to parse response body from {0}:{1}".format(ip, e))
                    continue

                self._cluster_id = resp_body["cluster_id"]
                self._license_id = resp_body["license_id"]
                self._public_key = resp_body["public_key"]

                if json_obj["clusterId"] == "" or json_obj["clusterId"] == resp_body["cluster_id"]:
                    json_obj["clusterId"] = resp_body["cluster_id"]
                else:
                    print("Inconsistent cluster id.")
                    return False

                if json_obj["license"] == "" or json_obj["license"] == resp_body["license_id"]:
                    json_obj["license"] = resp_body["license_id"]
                else:
                    print("Inconsistent licence id")
                    return False

                json_obj["ehs"].append(resp_body["request"])
            else:
                print("Fail to get license request : {} {}".format(code, reason))

        content = json.dumps(json_obj)
        try:
            f = open(output_path, "w")
            f.write(content)
            f.close()
        except Exception as e:
            print("Failed to write license request to file: {0}".format(e))

        return True

    def LoadLicense(self, lcs_path):
        lcs_str = ""
        try:
            f = open(lcs_path, 'rb')
            lcs_str = f.read()
            f.close()
        except Exception as e:
            print("read license file failed: {}".format(e))
            return False

        body = {
            "license_raw" : str(base64.b64encode(lcs_str), encoding="utf-8")
        }
        
        req_body = json.dumps(body)
        header = {"Content-type": "application/json"}
        for ip in self._controller_ips:
            conn = http.client.HTTPConnection(ip + ":8010", timeout=10)
            try:
                conn.request("POST", "/api/v1/license_reload", req_body, headers=header)
            except Exception as e:
                print("Failed to connect to {0}:{1}".format(ip, e))
                continue

            response = conn.getresponse()
            code = response.status
            reason = response.reason
            if code != 200:
                print("Failed to load license, ip: {0}".format(ip))
                return False

        return True

def print_usage_and_exit(code = 1):
    if not isinstance(code, int):
        code = 1

    print("Invalid usage", file=sys.stderr)
    print("tools.py <command> [options]", file=sys.stderr)
    sys.exit(code)

if len(sys.argv) < 2:
    print_usage_and_exit()
    
root_path = os.path.join(os.path.dirname(__file__), "../..")
if sys.argv[1] == 'images':
    r = PacketManifestReader(os.path.join(root_path, 'resource/tools/package.json'))
    r.PrintImageTable()
elif sys.argv[1] == 'install':
    i = 2
    force = True
    roles = []
    while i < len(sys.argv):
        if sys.argv[i] == '--force':
            force = True
            i += 1
        else:
            roles.append(sys.argv[i])
            i += 1

    res = True
    d = Deployment(root_path, roles, force_install = force)
    try:
        if not d.Initialize():
            res = False
    except:
        t = sys.exc_info()
        print("Error ocurred during initialization. ex: {0}, backtrace: {1}.".format(t[1], traceback.print_tb(t[2])), file=sys.stderr)
        res = False

    if not res:
        sys.exit(1)

    try:
        if not d.Execute():
            res = False
    except:
        t = sys.exc_info()
        print("Error ocurred during deployment. ex: {0}, backtrace: {1}.".format(t[1], traceback.print_tb(t[2])), file=sys.stderr)
        res = False

    if not res:
        sys.exit(1)

elif sys.argv[1] == 'check':
    print("Checking python module dependency.")
elif sys.argv[1] == 'hosts':
    d = Deployment(root_path, None)
    d.PrintHosts()
elif sys.argv[1] == 'license':
    if len(sys.argv) < 3:
        print_usage_and_exit()

    d = Deployment(root_path, None)
    if not d.Initialize():
        print("Failed to initialize deployment.", file=sys.stderr)
        sys.exit(1)

    controller_ips = d.GetControllerIps()
    lcs = LicenseWorkflow(controller_ips)
    if sys.argv[2] == 'request':
        req_path = "license_req.json"
        cluster_info_paths = []
        i = 3
        while i < len(sys.argv):
            if sys.argv[i] == '-o':
                if i + 1 < len(sys.argv):
                    req_path = sys.argv[i + 1]
                    i += 2
                else:
                    sys.exit(1)
            else:
                cluster_info_paths.append(sys.argv[i])
                i += 1

        if len(cluster_info_paths) == 0:
            sys.exit(1)

        if not lcs.CollectHardwareInfo(cluster_info_paths[0], req_path):
            sys.exit(1)
        
        print("Generated license request successfully.", file=sys.stderr)
    elif sys.argv[2] == 'load':
        if len(sys.argv) < 4:
            print_usage_and_exit()

        if not lcs.LoadLicense(sys.argv[3]):
            sys.exit(1)
        print("Load license successfully.", file=sys.stderr)
    else:
        print_usage_and_exit()
else:
    print_usage_and_exit()
