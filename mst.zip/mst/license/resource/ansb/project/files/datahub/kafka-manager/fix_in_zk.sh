#!/bin/bash

./bin/zkCli.sh -server localhost:2181 << END
create /kafka-manager/mutex ""
create /kafka-manager/mutex/locks ""
create /kafka-manager/mutex/leases ""
END
