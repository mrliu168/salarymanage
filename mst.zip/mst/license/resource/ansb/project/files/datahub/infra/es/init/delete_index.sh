#!/bin/bash
time1=$(date -d '-30days' +'%Y%m%d')
time2=$(date -d '-31days' +'%Y%m%d')
es_conf="http://datahub_es:9200/"
tracer_user_install="tracer_user_install_"
tracer_user_process="tracer_user_process_"
tracer_user_sessions="tracer_user_sessions_"
tracer_call_sessions="tracer_call_sessions_"
curl -XDELETE ${es_conf}${tracer_user_install}${time1},${tracer_user_sessions}${time1},${tracer_call_sessions}${time1},${tracer_user_process}${time1}
curl -XDELETE ${es_conf}${tracer_user_install}${time2},${tracer_user_sessions}${time2},${tracer_call_sessions}${time2},${tracer_user_process}${time2}
