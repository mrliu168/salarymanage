#!/bin/bash
JAVA_OPTS="
-XX:+UseG1GC
-XX:+UnlockExperimentalVMOptions
-XX:MaxGCPauseMillis=100
-XX:-OmitStackTraceInFastThrow
-XX:ParallelGCThreads=2
-XX:+ParallelRefProcEnabled
-XX:+PerfDisableSharedMem
-XX:-ResizePLAB
-Xms1G
-Xmx1G
-XX:MaxTenuringThreshold=1
-XX:G1HeapWastePercent=10
-XX:G1MixedGCCountTarget=16
-XX:G1HeapRegionSize=2M
-XX:+PrintGCDetails
-XX:+PrintGCDateStamps
-XX:+UseGCLogFileRotation
-XX:NumberOfGCLogFiles=10
-XX:GCLogFileSize=20M
-Xloggc:/app/logs/gc.log"

exec java $JAVA_OPTS -jar /app/app.jar --spring.config.location=/app/app.properties
