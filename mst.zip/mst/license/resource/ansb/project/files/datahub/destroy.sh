#!/bin/bash

dir=$(pwd)

cd $dir/infra
docker-compose --env-file $dir/application.env down

cd $dir/dispatcher
docker-compose --env-file $dir/application.env down

cd $dir/metacore
docker-compose --env-file $dir/application.env down

cd $dir/rtc/assembly
docker-compose --env-file $dir/application.env down

cd $dir/rtc/indexer
docker-compose --env-file $dir/application.env down

cd $dir/rtc/logpersistence
docker-compose --env-file $dir/application.env down

cd $dir/aa
docker-compose --env-file $dir/application.env down

cd $dir
rm -rf mc kafka-manager metacore dispatcher infra aa rtc application.env

nw=`docker network ls -q --filter name=datahub`
if [[ -n $nw ]]; then
    docker network rm datahub
fi
