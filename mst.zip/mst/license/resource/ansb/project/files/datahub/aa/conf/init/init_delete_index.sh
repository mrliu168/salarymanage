#!bin/sh
echo "0 */6 * * * /bin/sh /usr/local/aa_report_service/delete_index.sh > /usr/local/aa_report_service/delete.log" >> /etc/crontabs/root
crond -b