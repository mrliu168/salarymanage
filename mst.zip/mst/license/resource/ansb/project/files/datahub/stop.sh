#!/bin/bash

dir=$(pwd)

#check application file

check_docker(){
  result=$(docker -v | grep "^Docker version" | wc -l | awk '$1=$1')
  if [ "$result" != "1" ]; then
    echo "Found no docker"
    exit 3
  fi
}

check_docker

if [ ! -f "$dir/application.env" ]; then
  echo "Can not find application.env from $dir"
  exit 4
fi

#stop dispatcher
cd $dir/dispatcher
docker-compose --env-file $dir/application.env down

#stop assembly
cd $dir/rtc/assembly
docker-compose --env-file $dir/application.env down

#stop indexer
cd $dir/rtc/indexer
docker-compose --env-file $dir/application.env down

#stop logpersistence
cd $dir/rtc/logpersistence
docker-compose --env-file $dir/application.env down

#stop metacore
cd $dir/metacore
docker-compose --env-file $dir/application.env down

#stop infra
cd $dir/infra
docker-compose --env-file $dir/application.env down

#stop alab and aa
cd $dir/aa
docker-compose --env-file $dir/application.env down


