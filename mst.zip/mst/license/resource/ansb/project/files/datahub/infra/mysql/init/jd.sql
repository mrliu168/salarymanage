CREATE USER 'jd'@'%' IDENTIFIED WITH mysql_native_password BY 'jd123!';

grant all on jd_config.* to 'jd'@'%';

create database jd_config;

use jd_config;

CREATE TABLE `jd_group_config` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'id',
  `group_json` text NOT NULL COMMENT 'group定义json',
  `is_valid` tinyint(4) NOT NULL DEFAULT '1' COMMENT ' 是否有效 ',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT ' 创建时间 ',
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT ' 修改时间 ',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='group定义';

CREATE TABLE `jd_producer_config` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'id',
  `config_json` varchar(1024) NOT NULL DEFAULT '{}' COMMENT 'json格式的producer config',
  `is_valid` tinyint(4) NOT NULL DEFAULT '1' COMMENT ' 是否有效 ',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT ' 创建时间 ',
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT ' 修改时间 ',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='kafka producer定义';


insert into jd_group_config (`group_json`)
values
('[{"topics":["raw"],"broker":"datahub_kafka:9092","testTopic":"raw_debug_log","id":1}]');

insert into jd_producer_config (`id`, `config_json`)
values
(1, '{"batchSize":2097152,"linger":100,"bufferMemory":536870912,"maxRequestSize":8388608}');
