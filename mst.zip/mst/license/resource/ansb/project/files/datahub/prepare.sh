#!/bin/bash

data_conf_path=$1

copy_env(){
  if [ ! -f "$data_conf_path/application.env" ]; then
    echo "Can not find application.env from $data_conf_path"
    exit 3
  fi
  cp $data_conf_path/application.env ./application.env
}

check_cert(){
  if [ -e $data_conf_path/sdk.crt ]; then
    echo "sdk crt found"
  else
    echo "sdk crt not found in $data_conf_path/sdk.crt"
    exit 3
  fi
  if [ -e $data_conf_path/sdk.pem ]; then
    echo "sdk pem found"
  else
    echo "sdk pem not found in $data_conf_path/sdk.pem"
    exit 3
  fi
  if [ -e $data_conf_path/wrtc.crt ]; then
    echo "wrtc crt found"
  else
    echo "wrtc crt not found in $data_conf_path/wrtc.crt"
    exit 3
  fi
  if [ -e $data_conf_path/wrtc.pem ]; then
    echo "wrtc pem found"
  else
    echo "wrtc pem not found in $data_conf_path/wrtc.pem"
    exit 3
  fi
}

check_vid_conf(){
  if [ -e $data_conf_path/vid.conf ]; then
    echo "vid conf found"
  else
    echo "vid conf found in $data_conf_path/vid.conf"
    exit 3
  fi
  cat $data_conf_path/vid.conf |tr -s '\n'| while read line
  do
    line=${line//[[:blank:]]/}
    array=(${line//,/ })
    re='^[0-9]+$'
    if ! [[ ${array[0]} =~ $re ]] ; then
      echo "vid.conf error: vid: ${array[0]} Not a number"
      exit 3
    fi
  done
}

#copy_env
check_cert
check_vid_conf

cp $data_conf_path/sdk.crt ./infra/nginx/cert/sdk/
cp $data_conf_path/sdk.pem ./infra/nginx/cert/sdk/
cp $data_conf_path/wrtc.crt ./infra/nginx/cert/wrtc/
cp $data_conf_path/wrtc.pem ./infra/nginx/cert/wrtc/

projects=`cat $data_conf_path/vid.conf |tr -s '\n'| while read line
do
  line=${line//[[:blank:]]/}
  array=(${line//,/ })
  echo -n "{\"companyId\":${array[0]},\"projectId\":\"${array[0]}\",\"vendorId\":${array[0]},\"name\":\"${array[1]}\",\"appid\":\"${array[0]}\"},"
done `
sed -i  '/projects/c\"projects":['${projects%?}'],' ./aa/conf/private-config.json

if [ -e $data_conf_path/vos.conf ]; then
    vos=`cat $data_conf_path/vos.conf`
    sed -i  '/VosLogServerBase/c\"VosLogServerBase":"http://'${vos}':8201/api/v1/logs"' ./aa/conf/private-config.json
fi
