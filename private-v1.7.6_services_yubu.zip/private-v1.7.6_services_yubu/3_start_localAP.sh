#!/bin/bash
docker run --pid host --network host --restart=unless-stopped --cap-add=NET_ADMIN --cap-add sys_ptrace \
--ulimit core=-1 --security-opt seccomp=unconfined -itd \
-v `pwd`/log:/var/log/agora/ \
-v `pwd`/tmp:/tmp \
--mount type=bind,source=`pwd`/agora,target=/etc/agora \
--name agora_local_ap \
registry.cn-hangzhou.aliyuncs.com/agoraio-public/agora_local_ap:release-v1_7_7-20220810 \
--vendor-ids 82bad3ec59654b0696e90e770eae75a5:377733 \
--tls-cert ap.377733.agora.local.crt --tls-cert-key ap.377733.agora.local-key.pem \
--web-cert server.crt --web-cert-key server.pem \
--max-cpu 50 \
--max-mem 1000000 \
--max-bandwidth 999999 \
--max-user-count 100