#!/bin/bash
docker run -i -t -d --pid host --network host --restart=unless-stopped --name agora_lpsync \
-v `pwd`/log:/var/log/agora/ \
-v `pwd`/tmp:/tmp/ \
registry.cn-hangzhou.aliyuncs.com/agoraio-public/agora_lpsync:release-v1_7_2-20220222