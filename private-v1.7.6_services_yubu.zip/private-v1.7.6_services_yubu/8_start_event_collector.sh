#!/bin/bash
docker run --pid host --network host --restart=unless-stopped --cap-add=NET_ADMIN --cap-add sys_ptrace \
--ulimit core=-1 --security-opt seccomp=unconfined -itd \
-v `pwd`/log:/var/log/agora/ \
-v `pwd`/tmp:/tmp \
--mount type=bind,source=`pwd`/agora,target=/etc/agora \
--name agora_event_collector registry.cn-hangzhou.aliyuncs.com/agoraio-public/agora_event_collector:release-v1_0_0-20220509 \
--report 172.16.16.35 --ap 172.16.16.35 --ip-for-client 172.16.16.35 \
--cert server.crt --cert-key server.pem