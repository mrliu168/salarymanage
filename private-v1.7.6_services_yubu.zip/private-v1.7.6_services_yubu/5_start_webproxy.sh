#!/bin/bash
docker run --pid host --network host --restart=unless-stopped --cap-add=NET_ADMIN --cap-add sys_ptrace \
--ulimit core=-1 --security-opt seccomp=unconfined -itd \
-v `pwd`/log:/var/log/agora/ \
-v `pwd`/tmp:/tmp \
--mount type=bind,source=`pwd`/agora,target=/etc/agora \
--name agora_web_proxy registry.cn-hangzhou.aliyuncs.com/agoraio-public/agora_web_proxy:release-v1_7_6-20220509 \
--ip-for-client 47.95.196.179 --ip-for-comm 172.22.145.99 --ap 172.22.145.99 \
--cert-path server.crt --cert-key-path server.pem \
--collector-ip 172.22.145.99 \
--domain-prefix private
